# SAFE SHIELD Technical Design

## Purpose
This document describes the supplied educational ESP32 prototype. It detects a high acceleration magnitude, raises a relay output, sends a GSM SMS, reads MAX30100 pulse-oximeter values and temperature, samples an FSR and battery ADC, and uploads values to an IoT endpoint.

## Architecture
See [`architecture.mmd`](architecture.mmd) for the Mermaid source diagram.

## Data flow
1. MPU6050 acceleration registers are read over a dedicated I²C bus (SDA 21, SCL 22).
2. The code converts raw axes to g using its current divisor and calculates `sqrt(ax² + ay² + az²)`.
3. If magnitude exceeds 4.0 g, `impact_flag` is set and relay GPIO 27 is driven HIGH.
4. The flag clears after 13 seconds without another qualifying impact.
5. The main task sends an SMS once per active event through UART2 (RX 16, TX 17).
6. MAX30100 is serviced by a separate FreeRTOS task on I²C SDA 25/SCL 26.
7. Temperature is read from the OneWire sensor on GPIO 4. FSR is read on GPIO 35. Battery ADC is read on GPIO 32 and controls LEDs on GPIO 14 and 5.
8. When Wi-Fi is connected, the sketch POSTs `value1` through `value6` every ~2 seconds.

## Interfaces
| Device | Interface | Pin(s) | Purpose |
|---|---|---|---|
| MPU6050 | I²C bus 1 | SDA 21, SCL 22 | Acceleration samples |
| MAX30100 | I²C default bus | SDA 25, SCL 26 | HR/SpO₂ estimates |
| DS18B20-compatible sensor | OneWire | GPIO 4 | Temperature |
| GSM modem | UART2 | RX 16, TX 17 | SMS alert |
| Relay | Digital output | GPIO 27 | Safe dummy-load output |
| FSR | ADC | GPIO 35 | Threshold input |
| Battery sense | ADC | GPIO 32 | Battery indicator |
| LEDs | Digital output | GPIO 14, 5 | Battery status |

## FreeRTOS tasks
- `Task_MPU_AccidentDetect`: reads acceleration and controls impact flag.
- `Task_MAX30100`: calls `pox.update()`.
- `Task_MainLogic`: handles SMS, relay reset, sensor values, battery/temperature reads, serial output, and cloud uploads.

## IoT payload
The POST body is URL-encoded:
- `value1`: impact flag
- `value2`: temperature in °C
- `value3`: heart-rate estimate
- `value4`: SpO₂ estimate
- `value5`: hard-coded systolic placeholder
- `value6`: hard-coded diastolic placeholder

## Known limitations / future work
- A single acceleration threshold is not a validated fall detector and may produce false positives or false negatives.
- Verify MPU6050 range configuration and raw-to-g conversion.
- FSR values are not blood-pressure measurements; the 115/75 values are hard-coded placeholders.
- `WiFiClientSecure::setInsecure()` skips certificate verification; use certificate validation for deployment.
- Add GSM response parsing, HTTP error handling, Wi-Fi reconnection, sensor fault handling, and timestamped event logging.
- Heart rate and SpO₂ are estimates and require signal-quality checks and comparison with appropriate reference equipment.
- Actual airbag mechanics and inflation safety are not implemented or validated by this firmware.

## Safety
Do not connect relay GPIO to a real airbag inflator or hazardous actuator. Use an LED or low-voltage dummy load. This prototype is not a certified medical device and must not be used as the sole means of protecting a person.
