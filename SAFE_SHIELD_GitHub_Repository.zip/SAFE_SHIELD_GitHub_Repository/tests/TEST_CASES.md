# SAFE SHIELD manual test cases

These are safe bench tests. Use an LED or low-voltage dummy load for relay output. Sample data is illustrative, not clinical evidence.

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Startup | Upload firmware; Serial Monitor at 115200 baud | Startup and sensor status messages appear |
| TC-02 | MPU6050 | Move sensor gently in controlled conditions | Acceleration data changes plausibly |
| TC-03 | No impact | Keep sensor stationary | Impact flag remains 0; relay LOW |
| TC-04 | Threshold trigger | Safely move sensor to generate a threshold event on a bench | If magnitude exceeds 4.0 g, flag becomes 1 and relay HIGH |
| TC-05 | Flag reset | Trigger then keep still | Flag clears after about 13 seconds since last trigger |
| TC-06 | GSM | Use test SIM and configured test recipient | SMS alert is received if modem/network are working |
| TC-07 | Wi-Fi upload | Use a test endpoint and connected Wi-Fi | POST fields `value1`–`value6` are received |
| TC-08 | Wi-Fi unavailable | Start without access point | Device continues; cloud upload is skipped |
| TC-09 | MAX30100 | Wire sensor correctly and place finger on it | Library provides estimates when signal quality permits |
| TC-10 | Temperature | Connect OneWire temperature sensor | Plausible temperature appears |
| TC-11 | FSR | Vary pressure and observe ADC threshold | At >= 3800, code sets 115/75 placeholders; otherwise 0/0 |
| TC-12 | Battery LEDs | Verify ADC and divider with safe input | Below 2700 turns red LED on; otherwise green LED |

## Test record
Record date, firmware revision, hardware/wiring, test ID, observations, pass/fail, and corrective action.

## Important
The acceleration trigger is not proof that a fall occurred. The FSR logic does not measure blood pressure. Do not intentionally fall or connect the prototype to a real airbag inflator.
