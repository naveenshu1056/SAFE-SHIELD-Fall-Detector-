/*
 * SAFE SHIELD prototype firmware
 * Source basis: code supplied by the project author in a PDF.
 * This is a prototype, not a certified medical or life-safety device.
 * Test relay output with an LED or safe low-voltage dummy load only.
 */
#include <Wire.h>
#include <MAX30100_PulseOximeter.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <HardwareSerial.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <math.h>

// Replace placeholders with your own local test configuration.
// Do not commit private credentials or real phone numbers to a public repository.
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* POST_URL = "https://your-server.example/post_value.php";
const char* ALERT_PHONE_NUMBER = "+CCXXXXXXXXXX";

#define ONE_WIRE_BUS 4
#define RXD2 16
#define TXD2 17
#define MPU_ADDR 0x68
#define relay_pin 27
#define FSR_PIN 35
#define red_led 14
#define green_led 5

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
TwoWire MPU_BUS = TwoWire(1);
PulseOximeter pox;
WiFiClientSecure client;

volatile float tempC = 0.0;
volatile float heartRate = 0.0;
volatile uint8_t spo2 = 0;
volatile int impact_flag = 0;
volatile float ax_g = 0.0, ay_g = 0.0, az_g = 0.0;

unsigned long impact_time = 0;
bool sms_sent = true;
int fsrValue = 0, systolic = 0, diastolic = 0;
unsigned long battery_time = 0;

void MPU_Write(uint8_t reg, uint8_t data) {
  MPU_BUS.beginTransmission(MPU_ADDR);
  MPU_BUS.write(reg);
  MPU_BUS.write(data);
  MPU_BUS.endTransmission();
}

int16_t MPU_Read16(uint8_t reg) {
  MPU_BUS.beginTransmission(MPU_ADDR);
  MPU_BUS.write(reg);
  MPU_BUS.endTransmission(false);
  MPU_BUS.requestFrom(MPU_ADDR, (uint8_t)2);
  if (MPU_BUS.available() >= 2) {
    return (int16_t)((MPU_BUS.read() << 8) | MPU_BUS.read());
  }
  return 0;
}

void send_gsm() {
  Serial2.println("AT");
  vTaskDelay(pdMS_TO_TICKS(1000));
  Serial2.println("AT+CMGF=1");
  vTaskDelay(pdMS_TO_TICKS(1000));
  Serial2.print("AT+CMGS=\"");
  Serial2.print(ALERT_PHONE_NUMBER);
  Serial2.println("\"");
  vTaskDelay(pdMS_TO_TICKS(1000));
  Serial2.print("SAFE SHIELD alert: possible impact detected.");
  Serial2.write(26);
  vTaskDelay(pdMS_TO_TICKS(2000));
}

void send_IOT() {
  HTTPClient http;
  if (http.begin(client, POST_URL)) {
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    String data = "value1=" + String(impact_flag) +
                  "&value2=" + String(tempC) +
                  "&value3=" + String(heartRate) +
                  "&value4=" + String(spo2) +
                  "&value5=" + String(systolic) +
                  "&value6=" + String(diastolic);
    int httpCode = http.POST(data);
    Serial.printf("IoT HTTP status: %d\n", httpCode);
    http.end();
  }
}

void Task_MPU_AccidentDetect(void *pvParameters) {
  for (;;) {
    int16_t ax = MPU_Read16(0x3B);
    int16_t ay = MPU_Read16(0x3D);
    int16_t az = MPU_Read16(0x3F);

    // Preserves the conversion used by the supplied prototype.
    // Verify it against the actual MPU6050 full-scale setting.
    ax_g = ax / 4096.0;
    ay_g = ay / 4096.0;
    az_g = az / 4096.0;

    float totalG = sqrt(ax_g * ax_g + ay_g * ay_g + az_g * az_g);
    if (totalG > 4.0) {
      digitalWrite(relay_pin, HIGH);
      impact_flag = 1;
      impact_time = millis();
    }

    if (impact_flag && (millis() - impact_time > 13000)) {
      impact_flag = 0;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

void Task_MAX30100(void *pvParameters) {
  for (;;) {
    pox.update();
    vTaskDelay(pdMS_TO_TICKS(1));
  }
}

void Task_MainLogic(void *pvParameters) {
  unsigned long lastTempRead = 0;
  unsigned long lastUpload = 0;
  sensors.setWaitForConversion(false);
  sensors.requestTemperatures();

  for (;;) {
    if (impact_flag && sms_sent) {
      send_gsm();
      sms_sent = false;
    } else if (!impact_flag) {
      digitalWrite(relay_pin, LOW);
      sms_sent = true;
    }

    float currentHeartRate = pox.getHeartRate();
    uint8_t currentSpO2 = pox.getSpO2();

    heartRate = (currentHeartRate >= 40.0 && currentHeartRate <= 180.0)
                    ? currentHeartRate : 0;
    spo2 = (currentSpO2 >= 70 && currentSpO2 <= 100) ? currentSpO2 : 0;

    if (millis() - battery_time > 10000) {
      battery_time = millis();
      long battery_sum = 0;
      for (int i = 0; i < 5; i++) {
        battery_sum += analogRead(32);
        vTaskDelay(pdMS_TO_TICKS(2));
      }
      int battery = battery_sum / 5;
      if (battery < 2700) {
        digitalWrite(red_led, HIGH);
        digitalWrite(green_led, LOW);
      } else {
        digitalWrite(red_led, LOW);
        digitalWrite(green_led, HIGH);
      }
      Serial.print("Battery Analog Value: ");
      Serial.println(battery);
    }

    if (millis() - lastTempRead > 1000) {
      lastTempRead = millis();
      tempC = sensors.getTempCByIndex(0);
      sensors.requestTemperatures();
    }

    fsrValue = analogRead(FSR_PIN);
    // Prototype placeholder only; this is NOT a blood-pressure measurement.
    if (fsrValue >= 3800) {
      systolic = 115;
      diastolic = 75;
    } else {
      systolic = 0;
      diastolic = 0;
    }

    if (millis() - lastUpload > 2000) {
      lastUpload = millis();
      Serial.printf("HR: %.1f | SpO2: %u | Temp: %.1f C | Impact: %d | BP placeholder: %d/%d\n",
                    heartRate, spo2, tempC, impact_flag, systolic, diastolic);
      if (WiFi.status() == WL_CONNECTED) {
        send_IOT();
      }
    }
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(relay_pin, OUTPUT);
  pinMode(red_led, OUTPUT);
  pinMode(green_led, OUTPUT);
  digitalWrite(relay_pin, LOW);
  digitalWrite(red_led, LOW);
  digitalWrite(green_led, LOW);

  sensors.begin();
  Serial2.begin(9600, SERIAL_8N1, RXD2, TXD2);

  MPU_BUS.begin(21, 22, 100000);
  MPU_Write(0x6B, 0x00);
  MPU_Write(0x1C, 0x10); // MPU6050 accelerometer range register setting

  Wire.begin(25, 26, 100000);
  if (pox.begin()) {
    pox.setIRLedCurrent(MAX30100_LED_CURR_27_1MA);
  } else {
    Serial.println("MAX30100 initialization failed; check wiring.");
    while (true) {
      delay(1000);
    }
  }

  WiFi.begin(ssid, password);
  Serial.print("Connecting to Wi-Fi");
  unsigned long wifiStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 20000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi connected.");
    // Prototype only. Replace with CA certificate validation for deployment.
    client.setInsecure();
  } else {
    Serial.println("Wi-Fi not connected; cloud upload will be skipped.");
  }

  xTaskCreatePinnedToCore(Task_MPU_AccidentDetect, "MPU", 4096, nullptr, 2, nullptr, 1);
  xTaskCreatePinnedToCore(Task_MAX30100, "MAX", 4096, nullptr, 3, nullptr, 1);
  xTaskCreatePinnedToCore(Task_MainLogic, "Main", 9216, nullptr, 1, nullptr, 0);
}

void loop() {
  vTaskDelete(nullptr);
}
