// Example only. Arduino does not load .env files automatically.
// Copy to secrets.h, include it from the sketch, and keep secrets.h untracked.
#pragma once
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* IOT_POST_URL = "https://your-server.example/post_value.php";
const char* ALERT_PHONE_NUMBER = "+CCXXXXXXXXXX";
