# SAFE SHIELD — Wearable Fall Detection Prototype

SAFE SHIELD is an ESP32-based educational prototype for detecting high-acceleration events, switching a relay output, sending a GSM SMS alert, reading selected sensor values, and uploading readings to an IoT endpoint.

## Repository contents

- `firmware/SAFE_SHIELD.ino` — prototype firmware transcribed from the supplied program, with private credentials replaced by placeholders.
- `firmware/secrets.example.h` — example configuration template.
- `docs/TECHNICAL_DESIGN.md` — architecture, interfaces, data flow, and limitations.
- `docs/architecture.mmd` — Mermaid architecture diagram source.
- `data/SAMPLE_DATA.csv` — illustrative sample records.
- `tests/TEST_CASES.md` — manual test plan.
- `LICENSE` — MIT License.
- `.gitignore` — excludes local secrets and build artifacts.

## Features represented by the prototype

- MPU6050 acceleration magnitude threshold for impact flagging.
- Relay output on impact (GPIO 27).
- GSM SMS notification through UART2.
- Wi-Fi HTTP POST upload to an IoT endpoint.
- MAX30100 pulse-oximeter library readings (heart rate and SpO₂ estimates).
- OneWire temperature sensor reading.
- FSR threshold logic and battery status LEDs.

## Hardware and pin mapping

| Component | ESP32 connection / setting |
|---|---|
| MPU6050 I²C bus | SDA GPIO 21, SCL GPIO 22, address `0x68` |
| MAX30100 I²C bus | SDA GPIO 25, SCL GPIO 26 |
| DS18B20-compatible OneWire sensor | GPIO 4 |
| GSM modem UART2 | ESP32 RX GPIO 16, TX GPIO 17, 9600 baud |
| Relay module | GPIO 27 |
| FSR analog input | GPIO 35 |
| Battery ADC input | GPIO 32 |
| Red LED | GPIO 14 |
| Green LED | GPIO 5 |

Confirm the wiring and voltage compatibility of your exact modules before powering the system.

## Software setup

1. Install Arduino IDE 2.x.
2. Install Espressif's ESP32 board support package through Boards Manager.
3. Install the Arduino libraries providing these headers:
   - `MAX30100_PulseOximeter.h`
   - `OneWire.h`
   - `DallasTemperature.h`
4. Open `firmware/SAFE_SHIELD.ino`.
5. In the sketch, replace `YOUR_WIFI_SSID`, `YOUR_WIFI_PASSWORD`, `YOUR_IOT_POST_URL`, and `+CCXXXXXXXXXX` with your own test settings. Keep real credentials private.
6. Configure your server to accept URL-encoded fields `value1` through `value6`.
7. Select the correct ESP32 board and port.
8. Upload the sketch and open Serial Monitor at 115200 baud.
9. Test sensor readings and communications individually before testing the relay output.
10. Use an LED or safe low-voltage dummy load for relay tests.

### Environment variables / secrets

Arduino firmware does not read a `.env` file automatically. This prototype uses compile-time configuration constants. For a real repository, use a private, untracked `secrets.h` file or build-system secrets. `.gitignore` excludes `firmware/secrets.h`.

The sketch currently contains placeholder constants directly so the example remains easy to inspect. Before deployment, move them into `secrets.h` and do not commit that file.

Suggested settings:
- Wi-Fi SSID and password
- IoT HTTPS endpoint
- SMS recipient number
- Impact threshold and hold time

## IoT payload

The sketch sends `application/x-www-form-urlencoded` fields approximately every two seconds while Wi-Fi is connected:

| Field | Meaning |
|---|---|
| `value1` | Impact flag, 0 or 1 |
| `value2` | Temperature in °C |
| `value3` | Heart-rate estimate |
| `value4` | SpO₂ estimate |
| `value5` | Placeholder systolic value |
| `value6` | Placeholder diastolic value |

**Important:** the FSR code assigns `115/75` when its ADC value is at least 3800. These values are hard-coded placeholders, not blood-pressure measurements. Do not present them as clinically valid readings.

## Known limitations

- This code uses a simple acceleration threshold (`totalG > 4.0`), not a validated fall-classification algorithm.
- Check MPU6050 scale configuration against the raw-to-g conversion before relying on the threshold.
- `WiFiClientSecure::setInsecure()` disables TLS certificate verification. Add certificate validation before deployment.
- SMS and HTTP responses are not robustly checked.
- The code blocks at startup until Wi-Fi connects.
- The MAX30100 values are estimates and require quality checks.
- No actual airbag inflation hardware is implemented in software; the relay is only an output.
- This is not a medical device and is not intended for clinical or life-safety use.

## Safety

Do not connect the relay to a real airbag inflator, pyrotechnic device, or other hazardous actuator. Do not intentionally fall to test the device. Validate with controlled bench tests and a safe dummy load. The prototype needs substantial engineering and safety validation before real-world use.

## License

Released under the MIT License. See `LICENSE`.
